// ==================== APP STATE / DUMMY DATA ====================
let tasks = [
  { id: 1, name: 'Review DBMS lecture notes', priority: 'medium', due: '2026-06-18', done: false },
  { id: 2, name: 'Buy groceries & snacks', priority: 'low', due: '2026-06-16', done: false },
  { id: 3, name: 'Prepare slide deck for Networks presentation', priority: 'high', due: '2026-06-17', done: false },
  { id: 4, name: 'Submit Calculus worksheet (Ch 5)', priority: 'low', due: '2026-06-19', done: true },
  { id: 5, name: 'Forensics lab report', priority: 'medium', due: '2026-06-21', done: true },
  { id: 6, name: 'Math assignment – Integration', priority: 'high', due: '2026-06-17', done: false },
  { id: 7, name: 'Update portfolio on GitHub', priority: 'low', due: '2026-06-22', done: true },
  { id: 8, name: 'Revise SQL queries', priority: 'medium', due: '2026-06-23', done: true },
];
let taskIdCounter = 9;

let assignments = [
  { id: 1, subject: 'DBMS', name: 'ER Diagram – Student DB', deadline: '2026-06-20', status: 'pending' },
  { id: 2, subject: 'Mathematics', name: 'Integration Problems Set', deadline: '2026-06-17', status: 'pending' },
  { id: 3, subject: 'Web Development', name: 'LifeSync Frontend', deadline: '2026-06-25', status: 'done' },
  { id: 4, subject: 'Digital Forensics', name: 'Autopsy Lab Report', deadline: '2026-06-10', status: 'late' },
  { id: 5, subject: 'Computer Networks', name: 'OSI Model Presentation', deadline: '2026-06-15', status: 'done' },
];
let assignIdCounter = 6;

let expenses = [
  { id: 1, name: 'Canteen lunch', category: 'Food', amount: 120, date: '2026-06-14' },
  { id: 2, name: 'Bus pass recharge', category: 'Travel', amount: 500, date: '2026-06-12' },
  { id: 3, name: 'Notebooks and pens', category: 'Education', amount: 350, date: '2026-06-10' },
  { id: 4, name: 'Sneakers online sale', category: 'Shopping', amount: 2100, date: '2026-06-08' },
  { id: 5, name: 'Coffee with friends', category: 'Food', amount: 450, date: '2026-06-05' },
  { id: 6, name: 'Semester exam fee', category: 'Education', amount: 710, date: '2026-06-02' },
];
let expIdCounter = 7;

let notes = [
  { id: 1, title: 'Normalisation Rules (1NF-3NF)', category: 'DBMS', content: '1NF: Atomic values. 2NF: Remove partial dependencies. 3NF: Remove transitive dependencies.', date: 'Jun 14' },
  { id: 2, title: 'Digital Evidence Types', category: 'Forensics', content: 'Autopsy: file carving, registry analysis, hash verification. FTK Imager for disk imaging.', date: 'Jun 10' },
  { id: 3, title: 'OSI Model Layers', category: 'Networks', content: '7 layers: Physical, Data Link, Network, Transport, Session, Presentation, Application.', date: 'Jun 8' },
];
let noteIdCounter = 4;

let books = [
  { id: 1, title: 'Atomic Habits', author: 'James Clear', status: 'reading', progress: 70, emoji: '📗' },
  { id: 2, title: 'Deep Work', author: 'Cal Newport', status: 'wish', progress: 0, emoji: '📘' },
  { id: 3, title: 'Show Your Work!', author: 'Austin Kleon', status: 'done', progress: 100, emoji: '📙' }
];
let bookIdCounter = 4;

let currentFilter = 'all';
let currentReadFilter = 'all';
let waterGlasses = 5;

// ==================== NAVIGATION ====================
function navigate(page, btn) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  
  document.getElementById('page-' + page).classList.add('active');
  if (btn) btn.classList.add('active');
  closeSidebar();
  
  if (page === 'todo') renderTasks();
  if (page === 'study') renderAssignments();
  if (page === 'expenses') { renderTransactions(); initExpCharts(); }
  if (page === 'reading') renderBooks();
  if (page === 'wellness') { initMoodChart(); updateCycle(); renderWater(); }
  if (page === 'dashboard') { renderDashTasks(); initDashCharts(); }
}

// ==================== SIDEBAR ====================
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
  document.getElementById('sidebarOverlay').classList.toggle('open');
}
function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebarOverlay').classList.remove('open');
}

// ==================== THEME TOGGLE ====================
function toggleTheme() {
  const html = document.documentElement;
  const isDark = html.getAttribute('data-theme') === 'dark';
  html.setAttribute('data-theme', isDark ? 'light' : 'dark');
  document.getElementById('themeToggleBtn').textContent = isDark ? '🌙 Light' : '🌙 Dark';
  
  // Re-render dashboard or expense charts to apply updated theme colors dynamically
  const activePage = document.querySelector('.page.active').id;
  if (activePage === 'page-dashboard') { initDashCharts(); }
  if (activePage === 'page-expenses') { initExpCharts(); }
  if (activePage === 'page-wellness') { initMoodChart(); }
}

// ==================== REALTIME CLOCK ====================
function updateTime() {
  const now = new Date();
  document.getElementById('currentTime').textContent = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
}
setInterval(updateTime, 1000);
updateTime();

// ==================== TOAST COMPONENT SYSTEM ====================
function showToast(msg) {
  const t = document.getElementById('toast');
  document.getElementById('toastMsg').textContent = msg;
  t.classList.remove('hidden');
  setTimeout(() => { t.classList.add('hidden'); }, 3000);
}

// ==================== MODAL HELPERS ====================
function openModal(type) {
  if (type === 'task') {
    document.getElementById('taskModalTitle').textContent = 'Add New Task';
    document.getElementById('taskName').value = '';
    document.getElementById('taskPriority').value = 'medium';
    document.getElementById('taskDue').value = '';
    document.getElementById('editingTaskId').value = '';
  }
  document.getElementById(`modal-${type}`).classList.add('open');
}
function closeModal(type) {
  document.getElementById(`modal-${type}`).classList.remove('open');
}

// ==================== TO-DO LIST LOGIC ====================
function setFilter(f, btn) {
  currentFilter = f;
  document.querySelectorAll('.filter-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderTasks();
}

function renderTasks() {
  const c = document.getElementById('tasksContainer');
  if (!c) return;
  
  const query = document.getElementById('taskSearch').value.toLowerCase();
  let filtered = tasks.filter(t => t.name.toLowerCase().includes(query));
  
  if (currentFilter === 'pending') filtered = filtered.filter(t => !t.done);
  else if (currentFilter === 'done') filtered = filtered.filter(t => t.done);
  else if (currentFilter === 'high') filtered = filtered.filter(t => t.priority === 'high');

  if (!filtered.length) {
    c.innerHTML = `<div class="empty-state"><div class="empty-icon">📋</div><div class="empty-title">No tasks found</div><div class="empty-sub">Add a new task to get started</div></div>`;
    return;
  }

  c.innerHTML = filtered.map(t => `
    <div class="task-card" id="tc-${t.id}">
      <div class="task-checkbox ${t.done ? 'done' : ''}" onclick="toggleTask(${t.id})">${t.done ? '✓' : ''}</div>
      <div class="task-info">
        <div class="task-name ${t.done ? 'done' : ''}">${t.name}</div>
        <div class="task-meta">
          <span class="priority-tag ${t.priority}">${t.priority.charAt(0).toUpperCase() + t.priority.slice(1)}</span>
          ${t.due ? `<span class="task-due">📅 ${formatDate(t.due)}</span>` : ''}
        </div>
      </div>
      <div class="task-actions">
        <button class="task-action-btn" onclick="editTask(${t.id})" title="Edit">✏️</button>
        <button class="task-action-btn" onclick="deleteTask(${t.id})" title="Delete">🗑️</button>
      </div>
    </div>
  `).join('');
}

function toggleTask(id) {
  const t = tasks.find(x => x.id === id);
  if (t) {
    t.done = !t.done;
    renderTasks();
    renderDashTasks();
  }
}

function editTask(id) {
  const t = tasks.find(x => x.id === id);
  if (!t) return;
  document.getElementById('taskModalTitle').textContent = 'Edit Task';
  document.getElementById('taskName').value = t.name;
  document.getElementById('taskPriority').value = t.priority;
  document.getElementById('taskDue').value = t.due;
  document.getElementById('editingTaskId').value = id;
  document.getElementById('modal-task').classList.add('open');
}

function deleteTask(id) {
  tasks = tasks.filter(t => t.id !== id);
  renderTasks();
  renderDashTasks();
  showToast('🗑️ Task deleted');
}

function saveTask() {
  const name = document.getElementById('taskName').value.trim();
  if (!name) { showToast('⚠️ Task name required'); return; }
  
  const editId = parseInt(document.getElementById('editingTaskId').value);
  if (editId) {
    const t = tasks.find(x => x.id === editId);
    t.name = name;
    t.priority = document.getElementById('taskPriority').value;
    t.due = document.getElementById('taskDue').value;
    showToast('✅ Task updated');
  } else {
    tasks.unshift({
      id: taskIdCounter++,
      name,
      priority: document.getElementById('taskPriority').value,
      due: document.getElementById('taskDue').value,
      done: false
    });
    showToast('🚀 Task added successfully');
  }
  closeModal('task');
  renderTasks();
  renderDashTasks();
}

// ==================== DASHBOARD TASKS SNAPSHOT ====================
function renderDashTasks() {
  const container = document.getElementById('dashTasksContainer');
  if (!container) return;
  
  let pending = tasks.filter(t => !t.done).slice(0, 4);
  if (!pending.length) {
    container.innerHTML = `<div class="empty-state"><div class="empty-icon">🎉</div><div class="empty-title">All tasks complete!</div></div>`;
    return;
  }
  container.innerHTML = pending.map(t => `
    <div class="task-mini">
      <div class="task-mini-check" onclick="toggleTask(${t.id})"></div>
      <div class="task-mini-info">
        <div class="task-mini-name">${t.name}</div>
        <div class="task-mini-due">${t.due ? formatDate(t.due) : 'No deadline'}</div>
      </div>
      <div class="priority-dot ${t.priority}"></div>
    </div>
  `).join('');
}

// ==================== STUDY PLANNER ARCHITECTURE ====================
function switchTab(tab, btn) {
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('#page-study .tab-btn').forEach(b => b.classList.remove('active'));
  
  document.getElementById('tab-' + tab).classList.add('active');
  btn.classList.add('active');
  
  if (tab === 'assignments') renderAssignments();
  if (tab === 'notes') renderNotes();
}

function renderAssignments() {
  const container = document.getElementById('assignmentsContainer');
  if (!container) return;
  
  if (!assignments.length) {
    container.innerHTML = `<div class="empty-state"><div class="empty-icon">📚</div><div class="empty-title">No assignments listed</div></div>`;
    return;
  }
  
  container.innerHTML = assignments.map(a => `
    <div class="assignment-card">
      <span class="subject-badge" style="background:rgba(124,106,247,0.1);color:var(--accent2)">${a.subject}</span>
      <div class="asgn-info">
        <div class="asgn-name">${a.name}</div>
        <div class="asgn-deadline">Due: ${formatDate(a.deadline)}</div>
      </div>
      <span class="status-badge ${a.status}">${a.status.toUpperCase()}</span>
      <button class="task-action-btn" onclick="deleteAssignment(${a.id})">🗑️</button>
    </div>
  `).join('');
}

function saveAssignment() {
  const name = document.getElementById('assignName').value.trim();
  if (!name) { showToast('⚠️ Assignment name required'); return; }
  
  assignments.unshift({
    id: assignIdCounter++,
    subject: document.getElementById('assignSubject').value || 'General',
    name,
    deadline: document.getElementById('assignDeadline').value,
    status: document.getElementById('assignStatus').value
  });
  closeModal('assign');
  renderAssignments();
  showToast('✅ Assignment added');
}

function deleteAssignment(id) {
  assignments = assignments.filter(a => a.id !== id);
  renderAssignments();
  showToast('🗑️ Deleted');
}

// ==================== STUDY NOTES MODULE ====================
function renderNotes() {
  const c = document.getElementById('notesContainer');
  if (!c) return;
  if (!notes.length) {
    c.innerHTML = `<div class="empty-state"><div class="empty-icon">📝</div><div class="empty-title">No notes yet</div></div>`;
    return;
  }
  c.innerHTML = notes.map(n => `
    <div class="note-card">
      <span class="note-tag">${n.category}</span>
      <div style="display:flex;justify-content:space-between;align-items:start">
        <div class="note-title">${n.title}</div>
        <button class="task-action-btn" onclick="deleteNote(${n.id})" style="flex-shrink:0">🗑️</button>
      </div>
      <div class="note-preview">${n.content}</div>
      <div class="note-date">${n.date}</div>
    </div>
  `).join('');
}

function saveNote() {
  const title = document.getElementById('noteTitle').value.trim();
  if (!title) { showToast('⚠️ Title required'); return; }
  const now = new Date();
  notes.unshift({
    id: noteIdCounter++,
    title,
    category: document.getElementById('noteCategory').value || 'General',
    content: document.getElementById('noteContent').value,
    date: now.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })
  });
  closeModal('note');
  renderNotes();
  showToast('📝 Note saved');
}

function deleteNote(id) {
  notes = notes.filter(n => n.id !== id);
  renderNotes();
  showToast('🗑️ Deleted');
}

// ==================== EXPENSE MODULE OPERATIONS ====================
const catEmojis = { Food: '🍕', Travel: '🚌', Shopping: '🛍️', Education: '🎓', Other: '💳' };
const catColors = { Food: '#fbbf24', Travel: '#22d3ee', Shopping: '#f472b6', Education: '#7c6af7', Other: '#9095b4' };

function renderTransactions() {
  const container = document.getElementById('txContainer');
  if (!container) return;
  
  if (!expenses.length) {
    container.innerHTML = `<div class="empty-state"><div class="empty-icon">💸</div><div class="empty-title">No transactions registered</div></div>`;
    return;
  }
  container.innerHTML = expenses.slice(0, 5).map(e => `
    <div class="txn">
      <div class="txn-icon" style="background:rgba(255,255,255,0.04)">${catEmojis[e.category] || '💰'}</div>
      <div class="txn-info">
        <div class="txn-name">${e.name}</div>
        <div class="txn-cat">${e.category} • ${formatDate(e.date)}</div>
      </div>
      <div class="txn-amount expense">-₹${e.amount}</div>
    </div>
  `).join('');
}

function saveExpense() {
  const name = document.getElementById('expName').value.trim();
  const val = parseFloat(document.getElementById('expAmount').value);
  if (!name || isNaN(val)) { showToast('⚠️ Description & Amount required'); return; }
  
  expenses.unshift({
    id: expIdCounter++,
    name,
    amount: val,
    category: document.getElementById('expCategory').value,
    date: new Date().toISOString().split('T')[0]
  });
  closeModal('expense');
  renderTransactions();
  initExpCharts();
  showToast('💸 Expense recorded');
}

// ==================== READING SHELF HANDLERS ====================
function setReadFilter(f) {
  currentReadFilter = f;
  renderBooks();
}

function renderBooks() {
  const c = document.getElementById('booksContainer');
  if (!c) return;
  
  let filtered = books;
  if (currentReadFilter !== 'all') filtered = books.filter(b => b.status === currentReadFilter);
  
  document.getElementById('readingCount').textContent = books.filter(b => b.status === 'reading').length;
  document.getElementById('doneCount').textContent = books.filter(b => b.status === 'done').length;
  document.getElementById('wishCount').textContent = books.filter(b => b.status === 'wish').length;
  document.getElementById('totalBooks').textContent = books.length;

  if (!filtered.length) {
    c.innerHTML = `<div class="empty-state" style="grid-column:1/-1"><div class="empty-icon">📚</div><div class="empty-title">No books here</div></div>`;
    return;
  }
  
  const coverColors = ['#1a1e35', '#131629', '#1f2440', '#0d1525'];
  c.innerHTML = filtered.map((b, i) => `
    <div class="book-card">
      <div class="book-cover" style="background:${coverColors[i % coverColors.length]}">
        <span>${b.emoji || '📗'}</span>
        <span class="book-status-label ${b.status}">${b.status === 'reading' ? 'Reading' : b.status === 'done' ? 'Done' : 'Wishlist'}</span>
      </div>
      <div class="book-body">
        <div class="book-title">${b.title}</div>
        <div class="book-author">by ${b.author}</div>
        <div class="book-progress-row">
          <div class="book-progress-bar"><div class="book-progress-fill" style="width:${b.progress}%"></div></div>
          <div class="book-pct">${b.progress}%</div>
        </div>
        <div style="display:flex;gap:8px;margin-top:12px">
          <button class="btn-secondary" style="font-size:11px;padding:5px 10px;flex:1" onclick="updateBookProgress(${b.id})">Update %</button>
          <button class="task-action-btn" onclick="deleteBook(${b.id})">🗑️</button>
        </div>
      </div>
    </div>
  `).join('');
}

function saveBook() {
  const title = document.getElementById('bookTitle').value.trim();
  const author = document.getElementById('bookAuthor').value.trim();
  if (!title || !author) { showToast('⚠️ Title & Author details are required'); return; }
  
  books.unshift({
    id: bookIdCounter++,
    title,
    author,
    status: document.getElementById('bookStatus').value,
    progress: parseInt(document.getElementById('bookProgress').value) || 0,
    emoji: '📘'
  });
  closeModal('book');
  renderBooks();
  showToast('📚 Shelved successfully');
}

function updateBookProgress(id) {
  const b = books.find(x => x.id === id);
  if (!b) return;
  let val = prompt(`Enter progress % for ${b.title}:`, b.progress);
  if (val === null) return;
  val = parseInt(val);
  if (isNaN(val) || val < 0 || val > 100) { showToast('⚠️ Invalid calculation range'); return; }
  b.progress = val;
  if (val === 100) b.status = 'done';
  else if (val > 0 && b.status === 'wish') b.status = 'reading';
  renderBooks();
}

function deleteBook(id) {
  books = books.filter(b => b.id !== id);
  renderBooks();
  showToast('🗑️ Book removed');
}

// ==================== WELLNESS HANDLER TRACKS ====================
function logMood(score, btn) {
  document.querySelectorAll('.mood-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  showToast('📊 Emotional baseline tracked');
}

function renderWater() {
  const c = document.getElementById('waterCups');
  if (!c) return;
  let html = '';
  for (let i = 1; i <= 8; i++) {
    html += `<span class="water-cup ${i <= waterGlasses ? 'filled' : ''}" onclick="toggleWater(${i})">💧</span>`;
  }
  c.innerHTML = html;
  document.getElementById('waterCount').textContent = waterGlasses;
  document.getElementById('waterBar').style.width = `${(waterGlasses / 8) * 100}%`;
}

function toggleWater(index) {
  waterGlasses = index;
  renderWater();
}

function updateCycle() {
  const lastDate = new Date('2026-06-01');
  const cycleLen = 28;
  const today = new Date();
  
  const diffTime = Math.abs(today - lastDate);
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  const dynamicDaysLeft = cycleLen - (diffDays % cycleLen);
  
  document.getElementById('daysUntilPeriod').textContent = dynamicDaysLeft;
  
  const nextDate = new Date();
  nextDate.setDate(today.getDate() + dynamicDaysLeft);
  document.getElementById('nextPeriodDate').textContent = 'Expected: ' + nextDate.toLocaleDateString('en-IN', { day: 'numeric', month: 'long' });
  renderCycleDots(lastDate, cycleLen, today);
}

function renderCycleDots(lastDate, cycleLen, today) {
  const c = document.getElementById('cycleDots');
  if (!c) return;
  let html = '';
  for (let i = 0; i < cycleLen; i++) {
    const d = new Date(lastDate);
    d.setDate(d.getDate() + i);
    let cls = '';
    if (i < 5) cls = 'period';
    else if (i >= 11 && i <= 16) cls = 'fertile';
    if (d.toDateString() === today.toDateString()) cls = 'today';
    html += `<div class="cycle-dot ${cls}" title="Day ${i+1}"></div>`;
  }
  c.innerHTML = html;
}

// ==================== CHART OBJECT REFERENCES & UTILITIES ====================
let weeklyChart, expPieSmall, monthlyExpChart, moodChart;

const getChartDefaults = () => ({
  color: getComputedStyle(document.documentElement).getPropertyValue('--text2').trim() || '#9095b4',
  grid: getComputedStyle(document.documentElement).getPropertyValue('--border').trim() || 'rgba(255,255,255,0.07)',
});

function initDashCharts() {
  const d = getChartDefaults();
  
  // Weekly Focus Line/Bar
  const ctxWeekly = document.getElementById('weeklyChart');
  if (ctxWeekly) {
    if (weeklyChart) weeklyChart.destroy();
    weeklyChart = new Chart(ctxWeekly, {
      type: 'bar',
      data: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        datasets: [{
          label: 'Tasks Done',
          data: [3, 5, 2, 6, 4, 1, 3],
          backgroundColor: '#7c6af7',
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
          x: { ticks: { color: d.color }, grid: { display: false } },
          y: { ticks: { color: d.color }, grid: { color: d.grid } }
        }
      }
    });
  }

  // Dashboard Mini Expenses Pie
  const ctxPie = document.getElementById('expPieSmall');
  if (ctxPie) {
    if (expPieSmall) expPieSmall.destroy();
    const catData = getCatData();
    expPieSmall = new Chart(ctxPie, {
      type: 'doughnut',
      data: {
        labels: catData.labels,
        datasets: [{ data: catData.values, backgroundColor: catData.colors, borderWidth: 0 }]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: 'right', labels: { color: d.color } } },
        cutout: '70%'
      }
    });
  }
}

function initExpCharts() {
  const ctxMain = document.getElementById('monthlyExpChart');
  if (!ctxMain) return;
  if (monthlyExpChart) monthlyExpChart.destroy();
  
  const d = getChartDefaults();
  const catData = getCatData();
  
  monthlyExpChart = new Chart(ctxMain, {
    type: 'pie',
    data: {
      labels: catData.labels,
      datasets: [{ data: catData.values, backgroundColor: catData.colors }]
    },
    options: {
      responsive: true,
      plugins: { legend: { position: 'bottom', labels: { color: d.color } } }
    }
  });
}

function initMoodChart() {
  const ctxMood = document.getElementById('moodChart');
  if (!ctxMood) return;
  if (moodChart) moodChart.destroy();
  
  const d = getChartDefaults();
  moodChart = new Chart(ctxMood, {
    type: 'line',
    data: {
      labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      datasets: [{
        label: 'Mood',
        data: [4, 3, 2, 4, 5, 4, 4],
        borderColor: '#f472b6',
        backgroundColor: 'rgba(244,114,182,0.1)',
        fill: true,
        tension: 0.4,
        pointBackgroundColor: '#f472b6',
        pointRadius: 4
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: {
        x: { ticks: { color: d.color, font: { size: 11 } }, grid: { color: d.grid } },
        y: { 
          ticks: { 
            color: d.color, 
            callback: v => ['','😢','😰','😌','😊','🤩'][v] || v, 
            font: { size: 14 } 
          }, 
          grid: { color: d.grid }, 
          min: 1, 
          max: 5 
        }
      }
    }
  });
}

function getCatData() {
  const totals = {};
  expenses.forEach(e => { totals[e.category] = (totals[e.category] || 0) + e.amount; });
  const labels = Object.keys(totals);
  const values = Object.values(totals);
  const colors = labels.map(l => catColors[l] || '#7c6af7');
  return { labels, values, colors };
}

// ==================== HELPER FUNCTION CORES ====================
function formatDate(d) {
  if (!d) return '';
  return new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

// ==================== APPLICATION INITIALISATION ====================
window.addEventListener('DOMContentLoaded', () => {
  renderDashTasks();
  initDashCharts();
});